﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Player
{
    public partial class PlayerCreationForm : Form
    {
        public PlayerCreationForm()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            /*SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\cwarner\source\repos\Dungeoneers_All_In_One\DungeonMaster\Dungeoneering.mdf;Integrated Security=True");
            string CreateNewPlayer = "INSERT into Users (Username, Player Name, Player Type, Password) Values ('" + userNameTextBox.Text.Trim() + "', '" + PlayerNameTextBox.Text.Trim() + "', '"
                + PlayerTypeComboBox.SelectedText.Trim() + "', '" + PasswordTextBox.Text.Trim() + "')";
            SqlDataAdapter sda = new SqlDataAdapter(CreateNewPlayer, sqlcon);
            */
            using(SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\cwarner\source\repos\Dungeoneers_All_In_One\DungeonMaster\Dungeoneering.mdf;Integrated Security=True"))
            {
                sqlcon.Open();
                string freeUser = "SELECT COUNT(Username) from Users where Username = '"+ userNameTextBox.Text.Trim() + "'";
                using (SqlCommand sqlCommand = new SqlCommand(freeUser, sqlcon))
                {
                    int usercount = (int)sqlCommand.ExecuteScalar();
                    if(usercount > 0)
                    {
                        MessageBox.Show("User Already Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("useradd", sqlcon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@Username", userNameTextBox.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Player_Name", PlayerNameTextBox.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Player_Type", PlayerTypeComboBox.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Player_Points", 0);
                        sqlCmd.Parameters.AddWithValue("@Password", PasswordTextBox.Text.Trim());
                        sqlCmd.ExecuteNonQuery();
                    }
                }                
            }
            Logon login = new Logon();
            login.Show();
            this.Close();
        }
    }
}
