﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Player
{
    public partial class Logon : Form
    {
        public Logon()
        {
            InitializeComponent();
        }

        private void signinButton_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\cwarner\source\repos\Dungeoneers_All_In_One\DungeonMaster\Dungeoneering.mdf;Integrated Security=True");
            string logonQuery = "Select * from Users where username ='" + usernameTextBox.Text.Trim() + "' and Password = '" + passwordTextBox.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(logonQuery, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if(dtbl.Rows.Count == 1)
            {
                PlayerMainForm form = new PlayerMainForm();
                form.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("You are not a registered user..try again", "Access Denied",MessageBoxButtons.OK, MessageBoxIcon.Hand);
                Application.OpenForms["Startingform"].Show();
                this.Close();
            }
        }
    }
}
